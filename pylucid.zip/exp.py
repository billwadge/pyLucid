import pop,pio

def SubexpressionL(e):
    """ list of proper immediate subexpressions of e """
    if LiteralP(e): return pop.Empty
    if VarP(e): return pop.Empty
    if OperationP(e): return OperationOperandL(e)
    if CallP(e):
        callvar, actualslist = DeCall(e)
        return pop.Cons(callvar, actualslist)
    if DefinitionP(e):
        return List2(Lhs(e),Rhs(e))
    if WhereP(e): 
        subj, defs = WhereD(e)
        return pop.Cons(subj,defs)
    assert False, 'Weird term for subexp '+str(e)
    
def LocalsL(e):
    """ list of local or dummy variables of e """
    if DefinitionP(e):
        return DefinitionFormalsL(e)
    if WhereP(e):
        return WhereLocalsL(e)
    return pop.Empty
    
def Definee(d):
    """ the variable defined by definition d """
    lhs, rhs = DefinitionD(d)
    if VarP(lhs): return Var(lhs)
    if CallP(lhs) and VarP(CallFun(lhs)):
        return Var(CallFun(lhs))
    assert False, 'Definee cant handle '+str(d)
         
def LiteralC(i):
    """literal term for value i"""
    return pop.List2(DQUOTEWord,i)

def LiteralP(e):
    """ is e a literal?"""
    return pop.El1(e)==DQUOTEWord

def VarC(v):
    """return a term consisting of a var"""
    return pop.List2(VARWord,v)
    
def VarP(e):
    """does e consist of a variable?"""
    assert pop.ListP(e), 'VarP given nonlist '+str(e)
    return pop.El1(e)==VARWord
    
def Var(e):
    """"the variable from which the term e is constructed (assumes VarP(e))"""
    return pop.El2(e)
    
def IfP(e):
    return pop.El1(e) == IFWord
    
def IfCondition(e):
    return pop.El2(e)
    
def IfAlternativeTrue(e):
    return pop.El3(e)
    
def IfAlternativeFalse(e):
    return pop.El4(e)
    
def Deif(e):
    return IfCondition(e),IfAlternativeTrue(e),IfAlternativeFalse(e)
    
def CallC(f,l):
    """a function call with function f and arglist l"""
    assert pop.ListP(f), 'CallC given f nonexpression '+str(f)
    return pop.List3(CALLWord,f,l)
    
def WhereC(s,dl):
    """ create a where clause """
    return pop.List3(WHEREWord,s,dl)
    
def WhereP(t):
    return pop.Head(t) == WHEREWord
    
def WhereSubject(t):
    return pop.El2(t)
    
def WhereDefinitionsL(t):
    return pop.El3(t)
    
def WhereLocalsL(w):
    """ the local variables of where clause w """
    subj, defs = WhereD(w)
    res = pop.ConsAll(defs, Definee)
    return res
    
def WhereLhssL(w):
    subj, defs = WhereD(w)
    lhss = pop.Empty
    while defs != pop.Empty:
        d, defs = pop.ConsD(defs)
        lhs, rhs = DefinitionD(d)
        lhss = pop.Append(lhss,pop.List1(lhs))
    return lhss
    
def DeWhere(t):
    return WhereSubject(t),WhereDefinitionsL(t)
    
def WhereD(t):
    return WhereSubject(t),WhereDefinitionsL(t)
    
def CallP(t):
    return pop.Head(t) == CALLWord
    
def CallFun(t):
    """ the funcion being called """
    """ an expression """
    return pop.El2(t)
    
def CallActualsL(t):
    """ the arglist of the call t """
    return pop.El3(t)
    
def AcallC(funvar,len):
    return OperationC(ACALLWord, pop.List2(VarC(funvar),pop.NumC(len)))
    
def DeCall(t):
    return CallFun(t),CallActualsL(t)

def CallD(t):
    return CallFun(t),CallActualsL(t)
    
def ValofC(dl):
    return pop.Cons(VALOFWord,dl)
    
def DefinitionP(d):
    return pop.El1(d) == EQUALWord
    
def VarDefinitionP(d):
    if pop.El1(d) != EQUALWord: return False
    lhs, rhs = DefinitionD(d)
    return VarP(lhs)
    
def FunDefinitionP(d):
    if pop.El1(d) != EQUALWord: return False
    lhs, rhs = DefinitionD(d)
    return CallP(lhs)
    
def DeFunDefinition(d):
    lhs, rhs = DefinitionD(d)
    fun, formals = DeCall(lhs)
    return Var(fun), formals, rhs
    
def FunDefinitionD(d):
    lhs, rhs = DefinitionD(d)
    fun, formals = DeCall(lhs)
    forvars = pop.ConsAll(formals,Var)
    return Var(fun), forvars, rhs
    
def FunDefinitionC(v,forvars,rhs):
    formals = pop.ConsAll(forvars,VarC)
    fun = CallC(VarC(v),formals)
    return DefinitionC(fun,rhs)
    
def VarDefinitionD(d):
    lhs, rhs = DefinitionD(d)
    return Var(lhs), rhs
    
def DeVarDefinition(d):
    lhs, rhs = DefinitionD(d)
    return Var(lhs), rhs
       
def DefinitionC(lhs,rhs):
    return pop.List3(EQUALWord,lhs,rhs)
    
def DefinitionFormalsL(d):
    l,r= DefinitionD(d)
    if VarP(l): return pop.Empty
    acts =  CallActualsL(l)
    return pop.ConsAll(acts,Var)
    
def Lhs(d):
    return pop.El2(d)
    
def Rhs(d):
    return pop.El3(d)
    
def DeDefinition(d):
    return Lhs(d), Rhs(d)
    
def DefinitionD(d):
    return Lhs(d), Rhs(d)
    
def ListexpressionC(al):
    return pop.Cons(LLISTPARENWord,al)
    
def ListexpressionP(d):
    return pop.Head(d) == LLISTPARENWord
    
def SetexpressionC(al):
    return pop.Cons(LSETPARENWord,al)
    
def SetexpressionP(d):
    return pop.Head(d) == LSETPARENWord
    
def ListexpressionArgL(d):
    return pop.Tail(d)

def OperationP(e):
    """is e an operation constant applied to operands"""
    return OperationSymbolP(pop.El1(e))
    
def OperationSymbolP(o):
    return o in opsymbols

def OperationOperandL(e):
    """assumes OperationP(e), returns the list of operands """
    return pop.Tail(e)

def OperationOperand1(e):
    """assumes OperationP(e), returns the first operand"""
    return pop.El2(e)

def OperationOperand2(e):
    """assumes OperationP(e), returns the second operand"""
    return pop.El3(e)
    


def DeOperation(e):
    o = OperationSymbol(e)
    l = OperationOperandL(e)
    return o,l

def OperationD(e):
    o = OperationSymbol(e)
    l = OperationOperandL(e)
    return o,l
    
    
def LiteralValue(e):
    """assumes LiteralP(e), returns the value the expreesion denotes"""
    return pop.El2(e)

def OperationSymbol(e):
    """Assumes e is an operation applied to operands; returns the operation symbol"""
    if(LiteralP(e)): return e;
    return pop.El1(e)

def Operation0C(o):
    """create expression from 0-ary operator 0"""
    return pop.List1(o)
    
def Operation1C(o,e):
    return pop.List2(o,e)
    
def Operation2C(o,e1,e2):
    return pop.List3(o,e1,e2)
    
def Operation3C(o,e1,e2,e3):
    return pop.List4(o,e1,e2,e3)
    
def OperationC(o,el):
    return pop.Cons(o,el)

def Etype(t):
    """ return the type of term t is, as a string"""
    return pop.WordName(pop.Head(t))

def SetRprecedence(s,n):
    # symbol s binds with force n from the right 
    rpd[s] =n

def SetLprecedence(s,n):
    # symbol s binds with force n from the right 
    lpd[s] =n

def Rprecedence(s):
    return rpd[s]

def Lprecedence(s):
    return lpd[s]

def NewInfix(s):
    infixes.add(s)

def NewPostfix(s):
    postfixes.add(s)

def NewPrefix(s):
    prefixes.add(s)
    
def NewNullfix(s):
    nullfixes.add(s)
    
def InfixP(s):
    return pop.WordP(s) and s in infixes

def PostfixP(s):
    return pop.WordP(s) and s in postfixes

def PrefixP(s):
    return pop.WordP(s) and s in prefixes

def NullfixP(s):
    return pop.WordP(s) and s in nullfixes

def FixP(s):
    return InfixP(s) or PrefixP(s) or PostfixP(s) or NullfixP(s);

def NewFixes(k):
    while not pop.EmptyP(k):
        r = pop.Head(k); k = pop.Tail(k);
        lp = pop.NumVal(pop.El1(r)); s = pop.El2(r); rp = pop.NumVal(pop.El3(r));
        SetLprecedence(s,lp); SetRprecedence(s,rp)
        if(rp==100 and lp == 100): NewNullfix(s); continue
        if(lp==100): NewPrefix(s); continue
        if(rp==100): NewPostfix(s);  continue
        NewInfix(s)

def Reserve(l):
    s = set()
    while not pop.EmptyP(l):
        s.add(pop.Head(l))
        l = pop.Tail(l)
    return s


lpd = {}
rpd = {}

prefixes =set()
infixes = set()
postfixes = set()
nullfixes = set()
reservedwords = Reserve(pio.Popliteral("[if then else fi where end valof]"))

OPWord = pop.WordC('op')
VARWord =  pop.WordC('var')
DQUOTEWord = pop.WordC('"')
IFWord = pop.WordC("if")
THENWord = pop.WordC("then")
ELSEWord = pop.WordC("else")
FIWord = pop.WordC("fi")
CALLWord = pop.WordC("call")
YCALLWord = pop.WordC("ycall")
ACTUALWord = pop.WordC("actual")
GLOBALWord = pop.WordC("global")
WHEREWord = pop.WordC("where")
ENDWord = pop.WordC("end")
EQUALWord = pop.WordC("=")
SEMICOLONWord = pop.WordC(";")
VALOFWord = pop.WordC("valof")
LLISTPARENWord = pop.WordC("[%")
RLISTPARENWord = pop.WordC("%]")
LSETPARENWord = pop.WordC("{%")
RSETPARENWord = pop.WordC("%}")
OUTPUTWord = pop.WordC("output")
IDWord = pop.WordC("id")
EODWord = pop.WordC("eod")

NewFixes(pio.Popliteral("[[100 sin 65][100 cos 65][100 tan 65][100 exp 65][100 abs 40][100 log 65][100 log2 65][100 sqrt 65][100 pi 100][100 phi 100]]"))
NewFixes(pio.Popliteral("[[100 tl 65][100 not 65][100 isatom 65][100 islist 65][100 isnumber 65][100 isnil 65][100 iseod 65][100 isstring 65][100 isword 65][100 iserror 65]]"));
NewFixes(pio.Popliteral("[[100 first 65][100 init 65][100 id 65][100 succ 65][100 next 65][10 fby 9][10 sby 9][10 wvr 11][10 whr 11][10 asa 11][10 attime 11]]"))

NewFixes(pio.Popliteral("[[20 :: 19][25 or 24][30 and 29][40 <> 39][40 < 39][40 <= 39][40 eq 39][40 ne 39][40 >= 39][40 > 39][45 - 44][45 + 44][50 * 49][50 / 49][50 div 49][50 mod 49][55 ** 54][55 ^ 54][100 hd 65][100 index 100][100 eod 100][100 true 100][100 false 100]]"));

opsymbols = prefixes.union(infixes).union(prefixes).union(postfixes).union(nullfixes)
opsymbols.add(YCALLWord)
opsymbols.add(IFWord)
opsymbols.add(LLISTPARENWord)
opsymbols.add(ACTUALWord)
opsymbols.add(GLOBALWord)
opsymbols.add(EODWord)



Unterm = pop.List1(pop.WordC("unterm"))

