import pio,prp,exp,gen,prs,atz,pop,pre,ali,ari,map,ren,glb,ewh
from clc import *

codetable = {}
head = {}
tail = {}
warehouse = {}
Pempty = 0

newcode = 0
treg=0
preg = Pempty
evalcount = 0
actcount = 0
evaldepth  = 0
wsaves = 0
wfinds = 0

def Pcons(i,t):
    """ the hashcons (code) for the place code with head i and tail code t """
    global newcode
    if (i,t) in codetable: return codetable[(i,t)]
    newcode += 1
    codetable[(i,t)] = newcode
    head[newcode] = i
    tail[newcode] = t
    return newcode 
    
def PconsD(l):
    return head[l],tail[l]
    

def Eval(ap):
    """output of assembly program ap"""
    global AssemblyProgram,warehouse
    AssemblyProgram = ap
    s,val = EvalVar('output')
    return val
    
def WevalVar(v):
    global warehouse,wsaves,wfinds
    tag = (v,treg,preg)
    #print('>WevalVar '+str(tag))
    if tag in warehouse:
        val,age = warehouse[tag]
        wfinds += 1
        #print('Found it '+str(tag)+' = '+str(val))
        return val
    save, val = EvalVar(v)
    if save :
        warehouse[tag] = [val,0]
        wsaves += 1
        #print('Saved it '+str(tag)+' = '+str(val))
    return val
       
    
def EvalVar(v):
    """ value of var named v at time treg and place preg in AssemblyProgram"""
    global evalcount
    evalcount += 1
    #if evalcount >900: print('Tons of evals ');exit()
    global AssemblyProgram, strict,treg
    o, opds = AssemblyProgram[v]
    if o in strict: 
        return False,EvalStrict(o,opds)
    if o == '"': return False,opds           #opds is actually the literal value
    if o == 'fby': return True,Fby(opds)
    if o == 'first':return False, First(opds)
    if o == 'next':return False, Next(opds)
    if o == 'if': return True,If(opds)
    if o == 'actual': return True, Actual(opds)
    if o == 'ycall': return True, Ycall(opds)
    if o == 'and': return True, And(opds)
    if o == 'attime': return True, Attime(opds)
    if o == 'index': return False, NumC(treg) 
    assert False, 'ill defined variable: '+v+' '+o
    
def If(opds):
    p = WevalVar(opds[0])
    if pop.BoolVal(p):
        return WevalVar(opds[1])
    else:
        return WevalVar(opds[2])
        
def Attime(opds):
    global treg
    tsave = treg
    treg = NumVal(WevalVar(opds[1]))
    val = WevalVar(opds[0])
    treg = tsave
    return val
    
def Fby(opds):
    global treg
    if treg > 0: 
        treg -= 1
        val=WevalVar(opds[1])
        treg +=1
        return val
    return WevalVar(opds[0])
    
def First(opds):
    global treg
    tsave = treg
    treg=0
    val = WevalVar(opds[0])
    treg = tsave
    return val
    
def Next(opds):
    global treg
    treg += 1
    val = WevalVar(opds[0])
    treg -= 1
    return val

def Actual(opds):
    global preg,actcount
    actcount += 1
    ph,pt = PconsD(preg)
    act = opds[ph]
    psave = preg
    preg = pt
    val = WevalVar(act)
    preg =psave
    return val
    
def Ycall(opds):
    global preg
    n = NumVal(WevalVar(opds[1])) 
    f = opds[0]
    psave =preg
    preg = Pcons(n,preg)
    val = WevalVar(f)
    preg = psave
    return val


def And(opds):
    p = WevalVar(opds[0])
    if not pop.BoolVal(p):
        return pop.FALSEWord
    else:
        return WevalVar(opds[1])
    

def EvalStrict(o,opds):
    """ evaluate a strict data operation o applied to operands opds (var names) """
    resarray = []     
    for w in opds: #evaluate opds and collect array of results
        r = WevalVar(w)    #evaluate operand
        if pop.EodP(r):       # if eod shows up
            return pop.Eod     #return eod
        resarray.append(r) # collect result
    return Calculate(o,resarray) # calculate results


    """ produce assembly program asprog 
        a dictionary  which assigns to each variable an array of strings
        the operator followed by the operands
    """
def Assembly(aprog):
    global asprog
    subj,dl = exp.DeWhere(aprog)
    if exp.VarP(subj):
        subj = exp.Operation1C(exp.IDWord,subj)
    odef = exp.DefinitionC(exp.VarC(exp.OUTPUTWord),subj)
    dl = pop.Cons(odef,dl)
    asprog={}   #initialize the assembly program, a dictionary
            #that assigns to every variable name a tuple consisting
            #of the operation symbol and the array of the names of the variables
            #all python strings
    while dl != pop.Empty:              #loop through the definitions of the atomized program
        df,dl = pop.DeCons(dl) 
        lhs,rhs = exp.DeDefinition(df)  #dismantle current definition
        vname = pio.Words(exp.Var(lhs)) #get name of var being defined
        if exp.LiteralP(rhs):           #if its a literal treat quote mark as a pseudo op
            asprog[vname]= ('"',exp.LiteralValue(rhs))
            continue
        if exp.VarP(rhs):              # rhs a single variable, add id operator
            rhs = exp.Operation1C(exp.IDWord,rhs)
                                   #its an operation applied to operands
        o,ods = exp.DeOperation(rhs)    #break rhs into operation symbol and operand list
        odsa = []                      #initialize array of operands
        while ods != pop.Empty:        #iterate through operand list
            vw, ods = pop.DeCons(ods)  #get current operand, a var, and advance
            vws = pio.Words(exp.Var(vw))        #name of current operand, a var, as a string
            odsa.append(vws)    #append to the array
                                           #finished looping throug operands, so odsa complete
        asprog[vname] = (pio.Words(o),odsa)
        
if __name__ == "__main__":

    pg = prs.ParseFile("testprog.lu")
    print('Program is ')
    pio.WriteItemln(pg)
    prp.Termln(pg);
    print("check locals")
    pre.CheckLocals(pg)
    print("check dups")
    pre.CheckDups(pg)
    print("check embeddings")
    pre.ProgramEmbedded(pg)
    prp.Termln(pg)
    m = ari.Aritytab(pg,map.EmptyMap)
    print('Arity table')
    pio.WriteItemln(m)
    ok,var,arity = ari.ArityCheck(pg,m)
    if ok:
        print('arities check out ')
    else:
        prp.printf("Variable ")
        pio.WriteItem(var)
        prp.printf(" should have arity ")
        print(arity)
        exit()
    print('renamed program ')
    rpg = ren.Rename(pg,pop.EmptySet)
    prp.Termln(rpg)
    fpg = ewh.Eprogram(rpg)
    print('flattened program')
    prp.Termln(fpg)
    atab,ftab, ypg = ali.ActualTable(rpg,map.EmptyMap,map.EmptyMap)
    print('alified program')
    prp.Termln(ypg);
    defs = ali.ActualDefs(atab,ftab)
    subj,body =  exp.WhereD(ypg)
    body = pop.Append(body,defs)
    ypg = exp.WhereC(subj,body)
    print('globalized program')
    ypg = glb.Gprogram(ypg)
    prp.Termln(ypg)
    print('reflattend prorgram')
    ypg = ewh.Eprogram(ypg)
    prp.Termln(ypg)
    print('atomized program')
    apg,dfs = atz.Aexpr(ypg)
    prp.Termln(apg)
    asprog={}
    Assembly(apg)
   

    for vname in asprog:
        o,odsa = asprog[vname]
        prp.printf(vname+': ')
        if o == '"':
            prp.printf('" ');pio.WriteItemln(odsa)
            continue
        prp.printf(o+' ')
        for od in odsa: prp.printf(od);prp.printf(' ')
        print()
   
   
    """ eval program and print result """
    for t in range(15):
        treg = t
        val = Eval(asprog)
        if pop.EodP(val): break
        pio.WriteItemln(val)
    print('Number of evals: '+str(evalcount))
    print('warehouse saves '+str(wsaves)+' warehouse finds '+str(wfinds))
    print('Number of place codes generated '+str(newcode))
    print('Number of actual evals '+str(actcount))