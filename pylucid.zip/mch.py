from pop import *
returnblock = List1(WordC("return"))
running = False

def Machinate(b):
    """run the machine til the register and cstack are empty """
    global running,block,reg
    running = True
    Cpush(returnblock);Cpush(returnblock);
    block = b
    reg = b
    while (running):
        if (EmptyP(reg)): #at end of block
            Breakxec()
            continue
        token, reg = ConsD(reg)
        if not WordP(token):    #token is literal
            Vpush0(token)       #push on to stack
            continue
        if token == QUOTEWord and not EmptyP(reg): #a quoted token
            Vpush0(Head(reg)) #push next item
            reg = Tail(reg)   #advance reg
            continue
        p = opmap[token]     #a machine instruction
        if token in pmmap: #does it need a parameter?
            p(pmmap[token])
        else:
            p()
        running = True




def Mexec(b):
    global reg,block
    #/* execute block b thru to completion */
    Cpush(block)
    Cpush(reg)
    Cblayer()
    Machinate(b)
    Celayer()
    reg = Cpop()
    block = Cpop()

def Mblockbegin(b):
    global reg,block
    #/* set up b to be executed */
    #/* execution not attempted by this call */ 
    cpush(block)
    cpush(reg)
    block = b
    reg = b


def Doxec():
 	b = vtop0();
 	vpop0();
 	blockbegin(b);
    
def Ifxec():
    if Vtop(2) == TRUEWord:
        b= Vtop(1)
    else:
        b = Vtop0()
    Vpopn(3)
    blockbegin(b)

def EnterOp(nm,pr):
    """ enter pr in optable under name nm withouts parm"""
    opmap[nm] = pr

def Breakcxec():
    global reg,block
    b = vtop0()
 	val = vtop(1)
 	vpopn(2)
 	if (val == TRUEWord):
        block = b
        reg = b
        
Def Addxec():
    y = Vpop0()
    x = Vpop0()
    z = NumC(NumVal(X)+NumVal(y))
    Vpush0(z)
    
def Writexec():
    global reg,block
    i = Vpop0()
    pio.WriteItem(i)
    
def Breakxec():
    global reg,block
    reg = Cpop();block = Cpop();

def Loopxec():
    global reg,block
    reg = block;

def Loopcxec()
    global reg,block
 	b = Vpop0();
 	val = Vpop0();
 	if (val == TRUEWord):
        reg = block;
        Mblockbegin(b)

def Returnxec():
    global running
    running = FALSE
 


EnterOp("do",Doxec);
#EnterOp("edo",Edoxec);
EnterOp("loop",Loopxec);
EnterOp("loopc",Loopcxec);
EnterOp("break",Breakxec);
EnterOp("+",Addxec)
"""
EnterOp("breakc",Breakcxec);
#EnterOp("break2c",Break2cxec);
EnterOp("if",Ifxec);
#EnterOp("case",Casexec);
#EnterOp("ncase",Ncasexec);
#EnterOp("repeat",Repeatxec);
#EnterOp("for",Forxec);
#EnterOp("abort",Abortxec);
#EnterOp("trace",Tracexec);
EnterOp("quit",Quitxec);
#EnterOp("call",Callxec);
#EnterOp("arg",Argxec);
EnterOp("return",Returnxec);
EnterOp("(",Vstbeginlayerxec);
EnterOp(")",Vstendlayerxec);
"""

BREAKwrd = WordC("break")
QUOTEwrd = WordC('"')

block = Empty; reg = Empty

returnblock = List1(WordC("return"))
   
if __name__ == "__main__":
    while True:
        ln = input()
    cg = gen.CharStringC(prog)
    ig = pio.ItemGenChargenC(cg)
    prog = NextItem(ig)
    print("Popcode program is ")
    pio.WriteItemln(prog)
    Machinate(prog)


BREAKwrd = WordC("break");
QUOTEwrd = WordC('"');

block = Empty; reg = Empty;

returnblock = List1(WordC("return"));