""" commands to calculate data operations """

def EnterOp(s,p,m)
    """register popcode command s as  procedure p withparameter m """
    opmap[s] = p
    pmmap[s] = p
    

def Mcalc0(nm):
    Vpush0(Calculate(nm,[])

def Mcalc1(nm):
    """ perform unary operation nm on vstack """
    opds = [Vpop0()]
    Vpush0(Calculate(nm,opds))
    
def Mcalc2(nm)
    """ perform binaru operation nm on vstack """
    opd1 = Vpop0()
    opd0 = Vpop0()
    if opd0 == EODWord or opd1 == EODWord
        res = EODWORD
    else:
        res = Calculate(nm, [opd0,opd1])
    Vpush0(res)
    
    
for nm in ["+","*","**","/","eq","ne","<","<=",">",">=","mod","::"]:
    EnterOp(nm,Mcalc2,nm)
    
for nm in ["hd","tl","-","not","sin","cos","tan","exp","log","log10","abs","sqrt"]:
    EnterOp(nm,Mcalc1,nm)
    
        